This is an Arduino library for the DHT series of low cost temperature/humidity sensors. 

Tutorial: https://learn.adafruit.com/dht

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder DHT. Check that the DHT folder contains DHT.cpp and DHT.h. Place the DHT library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
